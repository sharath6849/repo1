package org.cap.test.bankapp;

public interface ReportCategory {

}
